<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <style>
        .phan-trang-center {
            display: flex;

        }

        .can-giua-pt {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
        }

        .phanTrang {
            display: flex;
            align-items: center;
            align-content: center;
            margin-right: 4px;
            width: 100%;
            height: 20px;
            padding: 5px;
            text-decoration: none;
            border: 1px solid #4b4b4a;
            border-radius: 5px;
        }

        strong {
            margin-right: 4px;
            display: flex;
            width: 100%;
            align-items: center;
            align-content: center;
            color: #fff;
            background: #515154;

            height: 20px;
            padding: 5px;
            text-decoration: none;
            border: 1px solid #4b4b4a;
            border-radius: 5px;
        }
    </style>
    <div class="phan-trang-center">
        <div class="can-giua-pt">
            <?php for ($i = 1; $i <= $total_pages; $i++) { ?>
                <?php if ($i != $current_page) { ?>
                    <a class="phanTrang" href="?<?= $param ?>per_page=<?= $item_per_page ?>&page=<?= $i ?>"><?= $i ?></a>
                <?php } else { ?>
                    <strong><?= $i ?></strong>
                <?php } ?>
            <?php } ?>
        </div>
    </div>
    <div class="about-used-iphone">
        <div class="search-iphone-appropriate">
            <div class="box-khung-001">
                <img class="img-search-001" src="../img/iPhone-13-pro-max.png" alt="">
                <div class="thong-tin-search">
                    <h3>Tìm iPhone phù hợp với bạn</h3>
                    <a class="so-sanh" href="#">
                        <p>So sánh các iPhone ></p>
                    </a>
                </div>
            </div>
            <div class="box-khung-001">
                <img class="img-search-001" src="../img/MHXH3_AV4_GEO_US.png" alt="">
                <div class="thong-tin-search">
                    <h3>Phụ kiện iPhone thường mua kèm</h3>
                    <a class="so-sanh" href="#">
                        <p>Tìm phụ kiện iPhone ></p>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="story-about-iphone">
        <div class="box-story">
            <h4>1. Lịch sử hình thành và phát triển của iPhone</h4>
            <p>iPhone là dòng điện thoại thông minh được phát triển từ Apple Inc, được ra mắt lần đầu tiên bởi Steve Jobs và mở bán năm 2007. Bên cạnh tính năng của một máy điện thoại thông thường, iPhone còn được trang bị màn hình cảm ứng, camera, khả năng chơi nhạc và chiếu phim, trình duyệt web,… Phiên bản thứ hai là iPhone 3G ra mắt tháng 7 năm 2008, được trang bị thêm hệ thống định vị toàn cầu, mạng 3G tốc độ cao.

                Trải qua 15 năm tính đến nay đã có đến 34 mẫu iPhone được sản xuất từ dòng 2G cho đến iPhone 13 Pro Max và Apple là một trong những thương hiệu điện thoại được yêu thích và sử dụng phổ biến nhất trên thế giới.</p>
            <h4>2. iPhone có những mã máy nào?</h4>
            <p>Những chiếc iPhone do Apple phân phối tại thị trường nước nào thì sẽ mang mã của nước đó. <br>

                Ví dụ:

            </p>
            <ul>
                <li>LL: Mỹ</li>
                <li>ZA: Singapore</li>
                <li>JA: Nhật Bản</li>
            </ul>
            <p>Những mã này xuất hiện tại Việt Nam đều là hàng xách tay, nhập khẩu. Còn tại Việt Nam, iPhone sẽ được mang mã VN/A. Tất cả các mã này đều là hàng chính hãng phân phối của Apple. Lợi thế khi bạn sử dụng iPhone mã VN/A đó là chế độ bảo hành tốt hơn với 12 tháng theo tiêu chuẩn của Apple.

                iPhone của bạn sẽ được bảo hành tại tất cả các trung tâm bảo hành Apple tại Việt Nam, một số mã quốc tế bị từ chối bảo hành và phải đem ra các trung tâm bảo hành Apple tại nước ngoài. Rất là phức tạp đúng không nào?</p>
            <h4>3. Apple đã khai tử những dòng iPhone nào?</h4>
            <p>Tính đến nay, Apple đã khai tử (ngừng sản xuất) các dòng iPhone đời cũ bao gồm: iPhone 2G, iPhone 3G, iPhone 4, iPhone 5 series, iPhone 6 series, iPhone 7 series, iPhone 8 series, iPhone X series, iPhone SE (thế hệ 1), iPhone SE (thế hệ 2), iPhone 11 Pro, iPhone 11 Pro Max, iPhone 12 Pro, iPhone 12 Pro Max.</p>
            <h4>4. ShopUcha cung cấp những dòng iPhone nào?</h4>
            <p>ShopDunk là một trong những thương hiệu bán lẻ được Apple uỷ quyền tại Việt Nam, đáp ứng được các yêu cầu khắt khe từ Apple như: dịch vụ kinh doanh, dịch vụ chăm sóc khách hàng, vị trí đặt cửa hàng,…</p>
            <p>Những chiếc iPhone do Apple Việt Nam phân phối tại nước ta đều mang mã VN/A và được bảo hành 12 tháng theo theo tiêu chuẩn tại các trung tâm bảo hành Apple. Các dòng iPhone được cung cấp tại ShopDunk gồm: iPhone 11, iPhone 12, iPhone 12 mini, iPhone 13 series, iPhone SE 3 (2022). </p>
            <ul>
                <li>Phone 11 được trang bị màn hình LCD và không hỗ trợ HDR, nâng cấp với chế độ chụp đêm Night Mode cùng Deep Fusion. Camera trước được nâng độ phân giải từ 7MP lên thành 12MP. Được trang bị chip A13 Bionic và hỗ trợ công nghệ WiFi 6. Với 6 màu sắc bắt mắt: Đen, Trắng, Xanh Mint, Đỏ, Vàng, Tím. </li>
                <li>iPhone 12 mini, iPhone 12 là những chiếc iPhone đầu tiên của hãng hỗ trợ mạng di động 5G. Apple đã thay đổi thiết kế của iPhone từ khung viền bo tròn thành khung viền vuông vức như những dòng iPhone 5 và sử dụng mặt kính trước Ceramic Shield. Ngoài ra, hộp của thiết bị iPhone 12 và các dòng iPhone sau đều đã được loại bỏ củ sạc.</li>
                <li>Tháng 9 năm 2021, Apple đã chính thức ra mắt 4 chiếc iPhone mới của hãng bao gồm iPhone 13 mini, iPhone 13, iPhone 13 Pro, iPhone 13 Pro Max. Các cụm Camera trên bộ 4 iPhone mới của Apple đều to hơn một chút so với thế hệ tiền nhiệm và phần tai thỏ ở mặt trước cũng được làm nhỏ hơn. Đối với iPhone 13 Pro và iPhone 13 Pro Max, Apple đã nâng cấp bộ nhớ tối đa của máy lên đến 1TB. Đi cùng với đó là tần số quét của dòng iPhone 13 cũng đã được nâng cấp lên 120Hz.</li>
                <li>iPhone SE thế hệ 3 (còn gọi là iPhone SE 3 hay iPhone SE 2022) được Apple công bố vào tháng 3 năm 2022, kế nhiệm iPhone SE 2. Đây là một phần của iPhone thế hệ thứ 15, cùng với iPhone 13 và iPhone 13 Pro. Thế hệ thứ 3 có kích thước và yếu tố hình thức của thế hệ trước, trong khi các thành phần phần cứng bên trong được lựa chọn từ dòng iPhone 13, bao gồm cả hệ thống trên chip A15 Bionic.</li>
            </ul>
            <h4>5. Mua iPhone giá tốt nhất tại ShopUcha</h4>
            <p>ShopDunk là đại lý uỷ quyền Apple tại Việt Nam với hệ thống 40 cửa hàng trên toàn quốc, trong đó có 11 Mono Store. Đến nay, ShopDunk đã trở thành điểm dừng chân lý tưởng cho iFans nói chung và thế hệ GenZ nói riêng bởi độ chuẩn và chất. Không gian thiết kế và bài trí sản phẩm theo tiêu chuẩn của Apple, chia theo từng khu vực rõ ràng, bàn trải nghiệm rộng rãi và đầy đủ sản phẩm.</p>
            <p>Tại ShopDunk luôn có mức giá tốt nhất cho người dùng cùng với nhiều chương trình hấp dẫn diễn ra liên tục trong tháng. Hãy đến với chúng tôi và trải nghiệm ngay những mẫu iPhone mới nhất với đội ngũ chuyên viên tư vấn được đào tạo bài bản từ Apple, sẵn sàng hỗ trợ bạn về sản phẩm, kỹ thuật hay các công nghệ mới nhất từ Apple.</p>
        </div>
    </div>
    </div>
    </div>
</body>

</html>